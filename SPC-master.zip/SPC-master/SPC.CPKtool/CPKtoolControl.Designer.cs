﻿namespace SPC.CPKtool
{
    partial class CPKtoolControl
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CPKtoolControl));
            DevExpress.XtraCharts.XYDiagram xyDiagram1 = new DevExpress.XtraCharts.XYDiagram();
            DevExpress.XtraCharts.ConstantLine constantLine8 = new DevExpress.XtraCharts.ConstantLine();
            DevExpress.XtraCharts.ConstantLine constantLine9 = new DevExpress.XtraCharts.ConstantLine();
            DevExpress.XtraCharts.ConstantLine constantLine10 = new DevExpress.XtraCharts.ConstantLine();
            DevExpress.XtraCharts.ConstantLine constantLine11 = new DevExpress.XtraCharts.ConstantLine();
            DevExpress.XtraCharts.ConstantLine constantLine12 = new DevExpress.XtraCharts.ConstantLine();
            DevExpress.XtraCharts.ConstantLine constantLine13 = new DevExpress.XtraCharts.ConstantLine();
            DevExpress.XtraCharts.SecondaryAxisY secondaryAxisY1 = new DevExpress.XtraCharts.SecondaryAxisY();
            DevExpress.XtraCharts.Series series2 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.Series series3 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.SplineSeriesView splineSeriesView1 = new DevExpress.XtraCharts.SplineSeriesView();
            DevExpress.XtraCharts.Series series4 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.SplineSeriesView splineSeriesView2 = new DevExpress.XtraCharts.SplineSeriesView();
            DevExpress.XtraCharts.SwiftPlotDiagram swiftPlotDiagram1 = new DevExpress.XtraCharts.SwiftPlotDiagram();
            DevExpress.XtraCharts.ConstantLine constantLine1 = new DevExpress.XtraCharts.ConstantLine();
            DevExpress.XtraCharts.ConstantLine constantLine2 = new DevExpress.XtraCharts.ConstantLine();
            DevExpress.XtraCharts.Strip strip1 = new DevExpress.XtraCharts.Strip();
            DevExpress.XtraCharts.ConstantLine constantLine3 = new DevExpress.XtraCharts.ConstantLine();
            DevExpress.XtraCharts.ConstantLine constantLine4 = new DevExpress.XtraCharts.ConstantLine();
            DevExpress.XtraCharts.ConstantLine constantLine5 = new DevExpress.XtraCharts.ConstantLine();
            DevExpress.XtraCharts.ConstantLine constantLine6 = new DevExpress.XtraCharts.ConstantLine();
            DevExpress.XtraCharts.ConstantLine constantLine7 = new DevExpress.XtraCharts.ConstantLine();
            DevExpress.XtraCharts.Strip strip2 = new DevExpress.XtraCharts.Strip();
            DevExpress.XtraCharts.Series series1 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.SwiftPlotSeriesView swiftPlotSeriesView1 = new DevExpress.XtraCharts.SwiftPlotSeriesView();
            DevExpress.XtraCharts.SwiftPlotSeriesView swiftPlotSeriesView2 = new DevExpress.XtraCharts.SwiftPlotSeriesView();
            this.barManager1 = new DevExpress.XtraBars.BarManager();
            this.bar2 = new DevExpress.XtraBars.Bar();
            this.barButtonItem3 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem9 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem10 = new DevExpress.XtraBars.BarButtonItem();
            this.barEditItem1 = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemComboBox2 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.barEditItem2 = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.barEditItem4 = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemComboBox3 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.standaloneBarDockControl1 = new DevExpress.XtraBars.StandaloneBarDockControl();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.barStaticItem1 = new DevExpress.XtraBars.BarStaticItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.barStaticItem2 = new DevExpress.XtraBars.BarStaticItem();
            this.barButtonItem5 = new DevExpress.XtraBars.BarButtonItem();
            this.barEditItem3 = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemTextEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.barButtonItem6 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem8 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem4 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem11 = new DevExpress.XtraBars.BarButtonItem();
            this.repositoryItemTextEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.chartControl2 = new DevExpress.XtraCharts.ChartControl();
            this.splitter3 = new System.Windows.Forms.Splitter();
            this.xtraScrollableControl1 = new DevExpress.XtraEditors.XtraScrollableControl();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.layoutView1 = new DevExpress.XtraGrid.Views.Layout.LayoutView();
            this.layoutViewColumn1 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn1 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn3 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn3 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn13 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.repositoryItemTextEdit5 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.layoutViewField_layoutViewColumn13 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn4 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.repositoryItemTextEdit6 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.layoutViewField_layoutViewColumn4 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn5 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.repositoryItemTextEdit7 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.layoutViewField_layoutViewColumn5 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn15 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn15 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn14 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn14 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn6 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn6 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn7 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn7 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn8 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn8 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn9 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn9 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn11 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn11 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn12 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn12 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn16 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn16 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn17 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn17 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn18 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn18 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn19 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn19 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn20 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn20 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn21 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.repositoryItemRadioGroup1 = new DevExpress.XtraEditors.Repository.RepositoryItemRadioGroup();
            this.layoutViewField_layoutViewColumn21 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn22 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn22 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn23 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn23 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn24 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn24 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn25 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn25 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn26 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn26 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn27 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn27 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn28 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn28 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn29 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn29 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn30 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn30 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn31 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn31 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn32 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn32 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn2 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn2 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn10 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumn10 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumn33 = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.repositoryItemTextEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.layoutViewField_layoutViewColumn33 = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewCard1 = new DevExpress.XtraGrid.Views.Layout.LayoutViewCard();
            this.Group1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.Group3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.Group4 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.Group2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.Group8 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.Group9 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.Group5 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.Group6 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.item2 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.Group10 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.item1 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.item3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.Group7 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.DataChart = new DevExpress.XtraCharts.ChartControl();
            this.splitter2 = new System.Windows.Forms.Splitter();
            this.panelControl3 = new DevExpress.XtraEditors.PanelControl();
            this.gridControl2 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new SPC.Base.Control.CanChooseDataGridView();
            this.chartPointRightClickPopupMenu = new DevExpress.XtraBars.PopupMenu();
            this.ChartBoundRightClickPopupMenu = new DevExpress.XtraBars.PopupMenu();
            this.gridViewRightClickPopupMenu = new DevExpress.XtraBars.PopupMenu();
            this.splitter1 = new System.Windows.Forms.Splitter();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(xyDiagram1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(secondaryAxisY1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(splineSeriesView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(splineSeriesView2)).BeginInit();
            this.xtraScrollableControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRadioGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewCard1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.item2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.item1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.item3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataChart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(swiftPlotDiagram1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(strip1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(strip2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(swiftPlotSeriesView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(swiftPlotSeriesView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).BeginInit();
            this.panelControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartPointRightClickPopupMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ChartBoundRightClickPopupMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewRightClickPopupMenu)).BeginInit();
            this.SuspendLayout();
            // 
            // barManager1
            // 
            this.barManager1.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.bar2});
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.DockControls.Add(this.standaloneBarDockControl1);
            this.barManager1.Form = this;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.barButtonItem3,
            this.barEditItem1,
            this.barEditItem2,
            this.barEditItem4,
            this.barStaticItem1,
            this.barButtonItem2,
            this.barStaticItem2,
            this.barButtonItem5,
            this.barEditItem3,
            this.barButtonItem6,
            this.barButtonItem8,
            this.barButtonItem9,
            this.barButtonItem10,
            this.barButtonItem4,
            this.barButtonItem11});
            this.barManager1.MainMenu = this.bar2;
            this.barManager1.MaxItemId = 31;
            this.barManager1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox2,
            this.repositoryItemTextEdit1,
            this.repositoryItemTextEdit2,
            this.repositoryItemComboBox3,
            this.repositoryItemTextEdit3});
            // 
            // bar2
            // 
            this.bar2.BarName = "Main menu";
            this.bar2.DockCol = 0;
            this.bar2.DockRow = 0;
            this.bar2.DockStyle = DevExpress.XtraBars.BarDockStyle.Standalone;
            this.bar2.FloatLocation = new System.Drawing.Point(806, 305);
            this.bar2.FloatSize = new System.Drawing.Size(0, 35);
            this.bar2.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem3),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem9),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem10),
            new DevExpress.XtraBars.LinkPersistInfo(this.barEditItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.barEditItem2),
            new DevExpress.XtraBars.LinkPersistInfo(this.barEditItem4)});
            this.bar2.OptionsBar.AllowQuickCustomization = false;
            this.bar2.OptionsBar.DrawDragBorder = false;
            this.bar2.OptionsBar.MultiLine = true;
            this.bar2.OptionsBar.UseWholeRow = true;
            this.bar2.StandaloneBarDockControl = this.standaloneBarDockControl1;
            this.bar2.Text = "Main menu";
            // 
            // barButtonItem3
            // 
            this.barButtonItem3.Caption = "计算CPK";
            this.barButtonItem3.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem3.Glyph")));
            this.barButtonItem3.Id = 8;
            this.barButtonItem3.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem3.LargeGlyph")));
            this.barButtonItem3.Name = "barButtonItem3";
            this.barButtonItem3.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph;
            this.barButtonItem3.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem3_ItemClick);
            // 
            // barButtonItem9
            // 
            this.barButtonItem9.Caption = "绘制";
            this.barButtonItem9.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem9.Glyph")));
            this.barButtonItem9.Id = 23;
            this.barButtonItem9.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem9.LargeGlyph")));
            this.barButtonItem9.Name = "barButtonItem9";
            this.barButtonItem9.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem9_ItemClick);
            // 
            // barButtonItem10
            // 
            this.barButtonItem10.Caption = "同步";
            this.barButtonItem10.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem10.Glyph")));
            this.barButtonItem10.Id = 24;
            this.barButtonItem10.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem10.LargeGlyph")));
            this.barButtonItem10.Name = "barButtonItem10";
            this.barButtonItem10.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem10_ItemClick);
            // 
            // barEditItem1
            // 
            this.barEditItem1.Caption = "属性";
            this.barEditItem1.Edit = this.repositoryItemComboBox2;
            this.barEditItem1.Id = 9;
            this.barEditItem1.Name = "barEditItem1";
            this.barEditItem1.Width = 122;
            this.barEditItem1.EditValueChanged += new System.EventHandler(this.barEditItem1_EditValueChanged);
            // 
            // repositoryItemComboBox2
            // 
            this.repositoryItemComboBox2.AllowMouseWheel = false;
            this.repositoryItemComboBox2.Appearance.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.repositoryItemComboBox2.Appearance.Options.UseForeColor = true;
            this.repositoryItemComboBox2.AutoHeight = false;
            this.repositoryItemComboBox2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox2.Name = "repositoryItemComboBox2";
            this.repositoryItemComboBox2.NullText = "选择属性";
            this.repositoryItemComboBox2.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            // 
            // barEditItem2
            // 
            this.barEditItem2.Caption = "数据组数：";
            this.barEditItem2.Edit = this.repositoryItemTextEdit1;
            this.barEditItem2.Id = 10;
            this.barEditItem2.Name = "barEditItem2";
            this.barEditItem2.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph;
            this.barEditItem2.Width = 32;
            this.barEditItem2.EditValueChanged += new System.EventHandler(this.barEditItem2_EditValueChanged);
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.AutoHeight = false;
            this.repositoryItemTextEdit1.Mask.EditMask = "f0";
            this.repositoryItemTextEdit1.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            // 
            // barEditItem4
            // 
            this.barEditItem4.Caption = "标准差估算方式";
            this.barEditItem4.Edit = this.repositoryItemComboBox3;
            this.barEditItem4.Id = 12;
            this.barEditItem4.Name = "barEditItem4";
            this.barEditItem4.Width = 76;
            this.barEditItem4.EditValueChanged += new System.EventHandler(this.barEditItem4_EditValueChanged);
            // 
            // repositoryItemComboBox3
            // 
            this.repositoryItemComboBox3.AllowMouseWheel = false;
            this.repositoryItemComboBox3.AutoHeight = false;
            this.repositoryItemComboBox3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox3.Name = "repositoryItemComboBox3";
            // 
            // standaloneBarDockControl1
            // 
            this.standaloneBarDockControl1.AutoSize = true;
            this.standaloneBarDockControl1.CausesValidation = false;
            this.standaloneBarDockControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.standaloneBarDockControl1.Location = new System.Drawing.Point(2, 2);
            this.standaloneBarDockControl1.Name = "standaloneBarDockControl1";
            this.standaloneBarDockControl1.Size = new System.Drawing.Size(730, 27);
            this.standaloneBarDockControl1.Text = "standaloneBarDockControl2";
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Size = new System.Drawing.Size(1362, 0);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 586);
            this.barDockControlBottom.Size = new System.Drawing.Size(1362, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 0);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 586);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(1362, 0);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 586);
            // 
            // barStaticItem1
            // 
            this.barStaticItem1.Caption = "barStaticItem1";
            this.barStaticItem1.Id = 13;
            this.barStaticItem1.Name = "barStaticItem1";
            this.barStaticItem1.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "删除";
            this.barButtonItem2.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem2.Glyph")));
            this.barButtonItem2.Id = 14;
            this.barButtonItem2.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem2.LargeGlyph")));
            this.barButtonItem2.Name = "barButtonItem2";
            this.barButtonItem2.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem2_ItemClick);
            // 
            // barStaticItem2
            // 
            this.barStaticItem2.Caption = "barStaticItem2";
            this.barStaticItem2.Id = 16;
            this.barStaticItem2.Name = "barStaticItem2";
            this.barStaticItem2.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // barButtonItem5
            // 
            this.barButtonItem5.Caption = "删除点";
            this.barButtonItem5.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem5.Glyph")));
            this.barButtonItem5.Id = 17;
            this.barButtonItem5.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem5.LargeGlyph")));
            this.barButtonItem5.Name = "barButtonItem5";
            this.barButtonItem5.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem2_ItemClick);
            // 
            // barEditItem3
            // 
            this.barEditItem3.Caption = "X轴边界：";
            this.barEditItem3.Edit = this.repositoryItemTextEdit3;
            this.barEditItem3.Id = 18;
            this.barEditItem3.Name = "barEditItem3";
            // 
            // repositoryItemTextEdit3
            // 
            this.repositoryItemTextEdit3.AutoHeight = false;
            this.repositoryItemTextEdit3.Name = "repositoryItemTextEdit3";
            // 
            // barButtonItem6
            // 
            this.barButtonItem6.Caption = "删除X轴边界";
            this.barButtonItem6.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem6.Glyph")));
            this.barButtonItem6.Id = 19;
            this.barButtonItem6.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem6.LargeGlyph")));
            this.barButtonItem6.Name = "barButtonItem6";
            this.barButtonItem6.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem6_ItemClick);
            // 
            // barButtonItem8
            // 
            this.barButtonItem8.Caption = "导入";
            this.barButtonItem8.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem8.Glyph")));
            this.barButtonItem8.Id = 21;
            this.barButtonItem8.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem8.LargeGlyph")));
            this.barButtonItem8.Name = "barButtonItem8";
            this.barButtonItem8.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem8_ItemClick);
            // 
            // barButtonItem4
            // 
            this.barButtonItem4.Caption = "选择";
            this.barButtonItem4.Id = 25;
            this.barButtonItem4.Name = "barButtonItem4";
            this.barButtonItem4.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem4_ItemClick);
            // 
            // barButtonItem11
            // 
            this.barButtonItem11.Caption = "取消选择";
            this.barButtonItem11.Id = 26;
            this.barButtonItem11.Name = "barButtonItem11";
            // 
            // repositoryItemTextEdit2
            // 
            this.repositoryItemTextEdit2.AutoHeight = false;
            this.repositoryItemTextEdit2.Name = "repositoryItemTextEdit2";
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.chartControl2);
            this.panelControl1.Controls.Add(this.splitter3);
            this.panelControl1.Controls.Add(this.xtraScrollableControl1);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Margin = new System.Windows.Forms.Padding(0);
            this.panelControl1.MaximumSize = new System.Drawing.Size(621, 0);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(621, 586);
            this.panelControl1.TabIndex = 9;
            // 
            // chartControl2
            // 
            xyDiagram1.AxisX.Alignment = DevExpress.XtraCharts.AxisAlignment.Zero;
            constantLine8.AxisValueSerializable = "1";
            constantLine8.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            constantLine8.LineStyle.DashStyle = DevExpress.XtraCharts.DashStyle.Dash;
            constantLine8.Name = "Constant Line 1";
            constantLine8.Title.Visible = false;
            constantLine8.Visible = false;
            constantLine9.AxisValueSerializable = "1";
            constantLine9.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            constantLine9.LineStyle.DashStyle = DevExpress.XtraCharts.DashStyle.Dash;
            constantLine9.Name = "Constant Line 2";
            constantLine9.Title.Visible = false;
            constantLine9.Visible = false;
            constantLine10.AxisValueSerializable = "1";
            constantLine10.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            constantLine10.LineStyle.DashStyle = DevExpress.XtraCharts.DashStyle.Dash;
            constantLine10.Name = "Constant Line 3";
            constantLine10.Title.Visible = false;
            constantLine10.Visible = false;
            constantLine11.AxisValueSerializable = "1";
            constantLine11.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            constantLine11.LineStyle.DashStyle = DevExpress.XtraCharts.DashStyle.Dash;
            constantLine11.Name = "Constant Line 4";
            constantLine11.Title.Visible = false;
            constantLine11.Visible = false;
            constantLine12.AxisValueSerializable = "1";
            constantLine12.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            constantLine12.LineStyle.DashStyle = DevExpress.XtraCharts.DashStyle.Dash;
            constantLine12.Name = "Constant Line 5";
            constantLine12.Title.Visible = false;
            constantLine12.Visible = false;
            constantLine13.AxisValueSerializable = "1";
            constantLine13.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            constantLine13.LineStyle.DashStyle = DevExpress.XtraCharts.DashStyle.Dash;
            constantLine13.Name = "Constant Line 6";
            constantLine13.Title.Visible = false;
            constantLine13.Visible = false;
            xyDiagram1.AxisX.ConstantLines.AddRange(new DevExpress.XtraCharts.ConstantLine[] {
            constantLine8,
            constantLine9,
            constantLine10,
            constantLine11,
            constantLine12,
            constantLine13});
            xyDiagram1.AxisX.VisibleInPanesSerializable = "-1";
            xyDiagram1.AxisY.VisibleInPanesSerializable = "-1";
            xyDiagram1.EnableAxisXScrolling = true;
            xyDiagram1.EnableAxisXZooming = true;
            xyDiagram1.Margins.Bottom = 0;
            xyDiagram1.Margins.Left = 0;
            xyDiagram1.Margins.Right = 0;
            xyDiagram1.Margins.Top = 0;
            secondaryAxisY1.AxisID = 0;
            secondaryAxisY1.Name = "Secondary AxisY 1";
            secondaryAxisY1.VisibleInPanesSerializable = "-1";
            xyDiagram1.SecondaryAxesY.AddRange(new DevExpress.XtraCharts.SecondaryAxisY[] {
            secondaryAxisY1});
            this.chartControl2.Diagram = xyDiagram1;
            this.chartControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chartControl2.Legend.Visible = false;
            this.chartControl2.Location = new System.Drawing.Point(2, 2);
            this.chartControl2.MaximumSize = new System.Drawing.Size(621, 0);
            this.chartControl2.Name = "chartControl2";
            this.chartControl2.OptionsPrint.SizeMode = DevExpress.XtraCharts.Printing.PrintSizeMode.Stretch;
            this.chartControl2.Padding.Bottom = 0;
            this.chartControl2.Padding.Left = 0;
            this.chartControl2.Padding.Right = 0;
            this.chartControl2.Padding.Top = 0;
            series2.ArgumentScaleType = DevExpress.XtraCharts.ScaleType.Numerical;
            series2.LabelsVisibility = DevExpress.Utils.DefaultBoolean.False;
            series2.Name = "Series 1";
            series3.LabelsVisibility = DevExpress.Utils.DefaultBoolean.False;
            series3.Name = "Series 2";
            splineSeriesView1.AxisYName = "Secondary AxisY 1";
            splineSeriesView1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            splineSeriesView1.LineStyle.Thickness = 1;
            series3.View = splineSeriesView1;
            series4.LabelsVisibility = DevExpress.Utils.DefaultBoolean.False;
            series4.Name = "Series 3";
            splineSeriesView2.AxisYName = "Secondary AxisY 1";
            splineSeriesView2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            splineSeriesView2.LineStyle.Thickness = 1;
            series4.View = splineSeriesView2;
            this.chartControl2.SeriesSerializable = new DevExpress.XtraCharts.Series[] {
        series2,
        series3,
        series4};
            this.chartControl2.Size = new System.Drawing.Size(617, 199);
            this.chartControl2.TabIndex = 9;
            // 
            // splitter3
            // 
            this.splitter3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter3.Location = new System.Drawing.Point(2, 201);
            this.splitter3.Name = "splitter3";
            this.splitter3.Size = new System.Drawing.Size(617, 3);
            this.splitter3.TabIndex = 10;
            this.splitter3.TabStop = false;
            // 
            // xtraScrollableControl1
            // 
            this.xtraScrollableControl1.Controls.Add(this.gridControl1);
            this.xtraScrollableControl1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.xtraScrollableControl1.Location = new System.Drawing.Point(2, 204);
            this.xtraScrollableControl1.Margin = new System.Windows.Forms.Padding(0);
            this.xtraScrollableControl1.MaximumSize = new System.Drawing.Size(621, 380);
            this.xtraScrollableControl1.Name = "xtraScrollableControl1";
            this.xtraScrollableControl1.Size = new System.Drawing.Size(617, 380);
            this.xtraScrollableControl1.TabIndex = 16;
            // 
            // gridControl1
            // 
            this.gridControl1.Location = new System.Drawing.Point(0, 0);
            this.gridControl1.MainView = this.layoutView1;
            this.gridControl1.Margin = new System.Windows.Forms.Padding(0);
            this.gridControl1.MaximumSize = new System.Drawing.Size(621, 361);
            this.gridControl1.MenuManager = this.barManager1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemRadioGroup1,
            this.repositoryItemTextEdit4,
            this.repositoryItemTextEdit5,
            this.repositoryItemTextEdit6,
            this.repositoryItemTextEdit7});
            this.gridControl1.Size = new System.Drawing.Size(617, 361);
            this.gridControl1.TabIndex = 8;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.layoutView1});
            // 
            // layoutView1
            // 
            this.layoutView1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.layoutView1.CardHorzInterval = 0;
            this.layoutView1.CardMinSize = new System.Drawing.Size(0, 0);
            this.layoutView1.CardVertInterval = 0;
            this.layoutView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.LayoutViewColumn[] {
            this.layoutViewColumn1,
            this.layoutViewColumn3,
            this.layoutViewColumn13,
            this.layoutViewColumn4,
            this.layoutViewColumn5,
            this.layoutViewColumn15,
            this.layoutViewColumn14,
            this.layoutViewColumn6,
            this.layoutViewColumn7,
            this.layoutViewColumn8,
            this.layoutViewColumn9,
            this.layoutViewColumn11,
            this.layoutViewColumn12,
            this.layoutViewColumn16,
            this.layoutViewColumn17,
            this.layoutViewColumn18,
            this.layoutViewColumn19,
            this.layoutViewColumn20,
            this.layoutViewColumn21,
            this.layoutViewColumn22,
            this.layoutViewColumn23,
            this.layoutViewColumn24,
            this.layoutViewColumn25,
            this.layoutViewColumn26,
            this.layoutViewColumn27,
            this.layoutViewColumn28,
            this.layoutViewColumn29,
            this.layoutViewColumn30,
            this.layoutViewColumn31,
            this.layoutViewColumn32,
            this.layoutViewColumn2,
            this.layoutViewColumn10,
            this.layoutViewColumn33});
            this.layoutView1.GridControl = this.gridControl1;
            this.layoutView1.Name = "layoutView1";
            this.layoutView1.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.False;
            this.layoutView1.OptionsBehavior.AllowExpandCollapse = false;
            this.layoutView1.OptionsBehavior.AllowPanCards = false;
            this.layoutView1.OptionsBehavior.AllowRuntimeCustomization = false;
            this.layoutView1.OptionsBehavior.AllowSwitchViewModes = false;
            this.layoutView1.OptionsBehavior.ScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Never;
            this.layoutView1.OptionsCustomization.AllowFilter = false;
            this.layoutView1.OptionsCustomization.AllowSort = false;
            this.layoutView1.OptionsFilter.AllowColumnMRUFilterList = false;
            this.layoutView1.OptionsFilter.AllowFilterEditor = false;
            this.layoutView1.OptionsFilter.AllowFilterIncrementalSearch = false;
            this.layoutView1.OptionsFilter.AllowMRUFilterList = false;
            this.layoutView1.OptionsFilter.AllowMultiSelectInCheckedFilterPopup = false;
            this.layoutView1.OptionsFilter.FilterEditorUseMenuForOperandsAndOperators = false;
            this.layoutView1.OptionsFilter.ShowAllTableValuesInCheckedFilterPopup = false;
            this.layoutView1.OptionsFind.AllowFindPanel = false;
            this.layoutView1.OptionsFind.HighlightFindResults = false;
            this.layoutView1.OptionsFind.ShowClearButton = false;
            this.layoutView1.OptionsFind.ShowCloseButton = false;
            this.layoutView1.OptionsFind.ShowFindButton = false;
            this.layoutView1.OptionsHeaderPanel.EnableCarouselModeButton = false;
            this.layoutView1.OptionsHeaderPanel.EnableColumnModeButton = false;
            this.layoutView1.OptionsHeaderPanel.EnableCustomizeButton = false;
            this.layoutView1.OptionsHeaderPanel.EnableMultiColumnModeButton = false;
            this.layoutView1.OptionsHeaderPanel.EnableMultiRowModeButton = false;
            this.layoutView1.OptionsHeaderPanel.EnablePanButton = false;
            this.layoutView1.OptionsHeaderPanel.EnableRowModeButton = false;
            this.layoutView1.OptionsHeaderPanel.EnableSingleModeButton = false;
            this.layoutView1.OptionsItemText.TextToControlDistance = 0;
            this.layoutView1.OptionsLayout.Columns.AddNewColumns = false;
            this.layoutView1.OptionsLayout.Columns.RemoveOldColumns = false;
            this.layoutView1.OptionsView.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowAlways;
            this.layoutView1.OptionsView.ShowCardCaption = false;
            this.layoutView1.OptionsView.ShowCardExpandButton = false;
            this.layoutView1.OptionsView.ShowCardLines = false;
            this.layoutView1.OptionsView.ShowFieldHints = false;
            this.layoutView1.OptionsView.ShowFilterPanelMode = DevExpress.XtraGrid.Views.Base.ShowFilterPanelMode.Never;
            this.layoutView1.OptionsView.ShowHeaderPanel = false;
            this.layoutView1.TemplateCard = this.layoutViewCard1;
            // 
            // layoutViewColumn1
            // 
            this.layoutViewColumn1.Caption = "总样本数";
            this.layoutViewColumn1.FieldName = "Count";
            this.layoutViewColumn1.LayoutViewField = this.layoutViewField_layoutViewColumn1;
            this.layoutViewColumn1.Name = "layoutViewColumn1";
            this.layoutViewColumn1.OptionsColumn.AllowEdit = false;
            this.layoutViewColumn1.OptionsColumn.ReadOnly = true;
            // 
            // layoutViewField_layoutViewColumn1
            // 
            this.layoutViewField_layoutViewColumn1.EditorPreferredWidth = 91;
            this.layoutViewField_layoutViewColumn1.Location = new System.Drawing.Point(0, 0);
            this.layoutViewField_layoutViewColumn1.Name = "layoutViewField_layoutViewColumn1";
            this.layoutViewField_layoutViewColumn1.Size = new System.Drawing.Size(170, 26);
            this.layoutViewField_layoutViewColumn1.TextSize = new System.Drawing.Size(75, 17);
            // 
            // layoutViewColumn3
            // 
            this.layoutViewColumn3.Caption = "样本均值";
            this.layoutViewColumn3.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn3.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn3.FieldName = "Avg";
            this.layoutViewColumn3.LayoutViewField = this.layoutViewField_layoutViewColumn3;
            this.layoutViewColumn3.Name = "layoutViewColumn3";
            this.layoutViewColumn3.OptionsColumn.AllowEdit = false;
            this.layoutViewColumn3.OptionsColumn.ReadOnly = true;
            // 
            // layoutViewField_layoutViewColumn3
            // 
            this.layoutViewField_layoutViewColumn3.EditorPreferredWidth = 80;
            this.layoutViewField_layoutViewColumn3.Location = new System.Drawing.Point(0, 0);
            this.layoutViewField_layoutViewColumn3.Name = "layoutViewField_layoutViewColumn3";
            this.layoutViewField_layoutViewColumn3.Size = new System.Drawing.Size(159, 26);
            this.layoutViewField_layoutViewColumn3.TextSize = new System.Drawing.Size(75, 17);
            // 
            // layoutViewColumn13
            // 
            this.layoutViewColumn13.Caption = "规格值";
            this.layoutViewColumn13.ColumnEdit = this.repositoryItemTextEdit5;
            this.layoutViewColumn13.FieldName = "Standard";
            this.layoutViewColumn13.LayoutViewField = this.layoutViewField_layoutViewColumn13;
            this.layoutViewColumn13.Name = "layoutViewColumn13";
            // 
            // repositoryItemTextEdit5
            // 
            this.repositoryItemTextEdit5.AutoHeight = false;
            this.repositoryItemTextEdit5.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.repositoryItemTextEdit5.Name = "repositoryItemTextEdit5";
            // 
            // layoutViewField_layoutViewColumn13
            // 
            this.layoutViewField_layoutViewColumn13.EditorPreferredWidth = 54;
            this.layoutViewField_layoutViewColumn13.Location = new System.Drawing.Point(0, 0);
            this.layoutViewField_layoutViewColumn13.Name = "layoutViewField_layoutViewColumn13";
            this.layoutViewField_layoutViewColumn13.Size = new System.Drawing.Size(119, 26);
            this.layoutViewField_layoutViewColumn13.TextSize = new System.Drawing.Size(61, 17);
            this.layoutViewField_layoutViewColumn13.TextToControlDistance = 0;
            // 
            // layoutViewColumn4
            // 
            this.layoutViewColumn4.Caption = "上公差";
            this.layoutViewColumn4.ColumnEdit = this.repositoryItemTextEdit6;
            this.layoutViewColumn4.FieldName = "UpTole";
            this.layoutViewColumn4.LayoutViewField = this.layoutViewField_layoutViewColumn4;
            this.layoutViewColumn4.Name = "layoutViewColumn4";
            // 
            // repositoryItemTextEdit6
            // 
            this.repositoryItemTextEdit6.AutoHeight = false;
            this.repositoryItemTextEdit6.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.repositoryItemTextEdit6.Name = "repositoryItemTextEdit6";
            // 
            // layoutViewField_layoutViewColumn4
            // 
            this.layoutViewField_layoutViewColumn4.EditorPreferredWidth = 54;
            this.layoutViewField_layoutViewColumn4.Location = new System.Drawing.Point(0, 26);
            this.layoutViewField_layoutViewColumn4.Name = "layoutViewField_layoutViewColumn4";
            this.layoutViewField_layoutViewColumn4.Size = new System.Drawing.Size(119, 26);
            this.layoutViewField_layoutViewColumn4.TextSize = new System.Drawing.Size(61, 17);
            // 
            // layoutViewColumn5
            // 
            this.layoutViewColumn5.Caption = "下公差";
            this.layoutViewColumn5.ColumnEdit = this.repositoryItemTextEdit7;
            this.layoutViewColumn5.FieldName = "LowTole";
            this.layoutViewColumn5.LayoutViewField = this.layoutViewField_layoutViewColumn5;
            this.layoutViewColumn5.Name = "layoutViewColumn5";
            // 
            // repositoryItemTextEdit7
            // 
            this.repositoryItemTextEdit7.AutoHeight = false;
            this.repositoryItemTextEdit7.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.repositoryItemTextEdit7.Name = "repositoryItemTextEdit7";
            // 
            // layoutViewField_layoutViewColumn5
            // 
            this.layoutViewField_layoutViewColumn5.EditorPreferredWidth = 54;
            this.layoutViewField_layoutViewColumn5.Location = new System.Drawing.Point(0, 52);
            this.layoutViewField_layoutViewColumn5.Name = "layoutViewField_layoutViewColumn5";
            this.layoutViewField_layoutViewColumn5.Size = new System.Drawing.Size(119, 26);
            this.layoutViewField_layoutViewColumn5.TextSize = new System.Drawing.Size(61, 17);
            this.layoutViewField_layoutViewColumn5.TextToControlDistance = 0;
            // 
            // layoutViewColumn15
            // 
            this.layoutViewColumn15.Caption = "样本最大值";
            this.layoutViewColumn15.FieldName = "Max";
            this.layoutViewColumn15.LayoutViewField = this.layoutViewField_layoutViewColumn15;
            this.layoutViewColumn15.Name = "layoutViewColumn15";
            this.layoutViewColumn15.OptionsColumn.AllowEdit = false;
            this.layoutViewColumn15.OptionsColumn.ReadOnly = true;
            // 
            // layoutViewField_layoutViewColumn15
            // 
            this.layoutViewField_layoutViewColumn15.EditorPreferredWidth = 80;
            this.layoutViewField_layoutViewColumn15.Location = new System.Drawing.Point(0, 26);
            this.layoutViewField_layoutViewColumn15.Name = "layoutViewField_layoutViewColumn15";
            this.layoutViewField_layoutViewColumn15.Size = new System.Drawing.Size(159, 26);
            this.layoutViewField_layoutViewColumn15.TextSize = new System.Drawing.Size(75, 17);
            this.layoutViewField_layoutViewColumn15.TextToControlDistance = 0;
            // 
            // layoutViewColumn14
            // 
            this.layoutViewColumn14.Caption = "样本最小值";
            this.layoutViewColumn14.FieldName = "Min";
            this.layoutViewColumn14.LayoutViewField = this.layoutViewField_layoutViewColumn14;
            this.layoutViewColumn14.Name = "layoutViewColumn14";
            this.layoutViewColumn14.OptionsColumn.AllowEdit = false;
            this.layoutViewColumn14.OptionsColumn.ReadOnly = true;
            // 
            // layoutViewField_layoutViewColumn14
            // 
            this.layoutViewField_layoutViewColumn14.EditorPreferredWidth = 91;
            this.layoutViewField_layoutViewColumn14.Location = new System.Drawing.Point(0, 26);
            this.layoutViewField_layoutViewColumn14.Name = "layoutViewField_layoutViewColumn14";
            this.layoutViewField_layoutViewColumn14.Size = new System.Drawing.Size(170, 26);
            this.layoutViewField_layoutViewColumn14.TextSize = new System.Drawing.Size(75, 17);
            this.layoutViewField_layoutViewColumn14.TextToControlDistance = 0;
            // 
            // layoutViewColumn6
            // 
            this.layoutViewColumn6.Caption = "上规范限";
            this.layoutViewColumn6.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn6.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn6.FieldName = "UpStdLt";
            this.layoutViewColumn6.LayoutViewField = this.layoutViewField_layoutViewColumn6;
            this.layoutViewColumn6.Name = "layoutViewColumn6";
            this.layoutViewColumn6.OptionsColumn.AllowEdit = false;
            this.layoutViewColumn6.OptionsColumn.ReadOnly = true;
            // 
            // layoutViewField_layoutViewColumn6
            // 
            this.layoutViewField_layoutViewColumn6.EditorPreferredWidth = 77;
            this.layoutViewField_layoutViewColumn6.Location = new System.Drawing.Point(0, 0);
            this.layoutViewField_layoutViewColumn6.Name = "layoutViewField_layoutViewColumn6";
            this.layoutViewField_layoutViewColumn6.Size = new System.Drawing.Size(170, 26);
            this.layoutViewField_layoutViewColumn6.TextSize = new System.Drawing.Size(89, 17);
            // 
            // layoutViewColumn7
            // 
            this.layoutViewColumn7.Caption = "下规范限";
            this.layoutViewColumn7.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn7.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn7.FieldName = "LowStdLt";
            this.layoutViewColumn7.LayoutViewField = this.layoutViewField_layoutViewColumn7;
            this.layoutViewColumn7.Name = "layoutViewColumn7";
            this.layoutViewColumn7.OptionsColumn.AllowEdit = false;
            this.layoutViewColumn7.OptionsColumn.ReadOnly = true;
            // 
            // layoutViewField_layoutViewColumn7
            // 
            this.layoutViewField_layoutViewColumn7.EditorPreferredWidth = 80;
            this.layoutViewField_layoutViewColumn7.Location = new System.Drawing.Point(0, 0);
            this.layoutViewField_layoutViewColumn7.Name = "layoutViewField_layoutViewColumn7";
            this.layoutViewField_layoutViewColumn7.Size = new System.Drawing.Size(159, 26);
            this.layoutViewField_layoutViewColumn7.TextSize = new System.Drawing.Size(75, 17);
            // 
            // layoutViewColumn8
            // 
            this.layoutViewColumn8.Caption = "技术公差幅度";
            this.layoutViewColumn8.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn8.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn8.FieldName = "TOffsetWidth";
            this.layoutViewColumn8.LayoutViewField = this.layoutViewField_layoutViewColumn8;
            this.layoutViewColumn8.Name = "layoutViewColumn8";
            this.layoutViewColumn8.OptionsColumn.AllowEdit = false;
            this.layoutViewColumn8.OptionsColumn.ReadOnly = true;
            // 
            // layoutViewField_layoutViewColumn8
            // 
            this.layoutViewField_layoutViewColumn8.EditorPreferredWidth = 77;
            this.layoutViewField_layoutViewColumn8.Location = new System.Drawing.Point(0, 26);
            this.layoutViewField_layoutViewColumn8.Name = "layoutViewField_layoutViewColumn8";
            this.layoutViewField_layoutViewColumn8.Size = new System.Drawing.Size(170, 26);
            this.layoutViewField_layoutViewColumn8.TextSize = new System.Drawing.Size(89, 17);
            // 
            // layoutViewColumn9
            // 
            this.layoutViewColumn9.Caption = "公差中心值";
            this.layoutViewColumn9.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn9.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn9.FieldName = "OffsetMid";
            this.layoutViewColumn9.LayoutViewField = this.layoutViewField_layoutViewColumn9;
            this.layoutViewColumn9.Name = "layoutViewColumn9";
            this.layoutViewColumn9.OptionsColumn.AllowEdit = false;
            this.layoutViewColumn9.OptionsColumn.ReadOnly = true;
            // 
            // layoutViewField_layoutViewColumn9
            // 
            this.layoutViewField_layoutViewColumn9.EditorPreferredWidth = 77;
            this.layoutViewField_layoutViewColumn9.Location = new System.Drawing.Point(0, 52);
            this.layoutViewField_layoutViewColumn9.Name = "layoutViewField_layoutViewColumn9";
            this.layoutViewField_layoutViewColumn9.Size = new System.Drawing.Size(170, 26);
            this.layoutViewField_layoutViewColumn9.TextSize = new System.Drawing.Size(89, 17);
            // 
            // layoutViewColumn11
            // 
            this.layoutViewColumn11.Caption = "样本偏移量";
            this.layoutViewColumn11.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn11.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn11.FieldName = "SpOffset";
            this.layoutViewColumn11.LayoutViewField = this.layoutViewField_layoutViewColumn11;
            this.layoutViewColumn11.Name = "layoutViewColumn11";
            this.layoutViewColumn11.OptionsColumn.AllowEdit = false;
            this.layoutViewColumn11.OptionsColumn.ReadOnly = true;
            // 
            // layoutViewField_layoutViewColumn11
            // 
            this.layoutViewField_layoutViewColumn11.EditorPreferredWidth = 80;
            this.layoutViewField_layoutViewColumn11.Location = new System.Drawing.Point(0, 26);
            this.layoutViewField_layoutViewColumn11.Name = "layoutViewField_layoutViewColumn11";
            this.layoutViewField_layoutViewColumn11.Size = new System.Drawing.Size(159, 26);
            this.layoutViewField_layoutViewColumn11.TextSize = new System.Drawing.Size(75, 17);
            // 
            // layoutViewColumn12
            // 
            this.layoutViewColumn12.Caption = "样本偏移度";
            this.layoutViewColumn12.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn12.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn12.FieldName = "SpOffsetD";
            this.layoutViewColumn12.LayoutViewField = this.layoutViewField_layoutViewColumn12;
            this.layoutViewColumn12.Name = "layoutViewColumn12";
            this.layoutViewColumn12.OptionsColumn.AllowEdit = false;
            this.layoutViewColumn12.OptionsColumn.ReadOnly = true;
            // 
            // layoutViewField_layoutViewColumn12
            // 
            this.layoutViewField_layoutViewColumn12.EditorPreferredWidth = 80;
            this.layoutViewField_layoutViewColumn12.Location = new System.Drawing.Point(0, 52);
            this.layoutViewField_layoutViewColumn12.Name = "layoutViewField_layoutViewColumn12";
            this.layoutViewField_layoutViewColumn12.Size = new System.Drawing.Size(159, 26);
            this.layoutViewField_layoutViewColumn12.TextSize = new System.Drawing.Size(75, 17);
            // 
            // layoutViewColumn16
            // 
            this.layoutViewColumn16.Caption = "PPM Total entirety";
            this.layoutViewColumn16.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn16.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn16.FieldName = "SumBdRate_E";
            this.layoutViewColumn16.LayoutViewField = this.layoutViewField_layoutViewColumn16;
            this.layoutViewColumn16.Name = "layoutViewColumn16";
            this.layoutViewColumn16.OptionsColumn.AllowEdit = false;
            this.layoutViewColumn16.OptionsColumn.ReadOnly = true;
            // 
            // layoutViewField_layoutViewColumn16
            // 
            this.layoutViewField_layoutViewColumn16.EditorPreferredWidth = 254;
            this.layoutViewField_layoutViewColumn16.Location = new System.Drawing.Point(0, 203);
            this.layoutViewField_layoutViewColumn16.Name = "layoutViewField_layoutViewColumn16";
            this.layoutViewField_layoutViewColumn16.Size = new System.Drawing.Size(258, 26);
            this.layoutViewField_layoutViewColumn16.TextSize = new System.Drawing.Size(0, 0);
            this.layoutViewField_layoutViewColumn16.TextToControlDistance = 0;
            this.layoutViewField_layoutViewColumn16.TextVisible = false;
            // 
            // layoutViewColumn17
            // 
            this.layoutViewColumn17.Caption = "PPM>USL entirety";
            this.layoutViewColumn17.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn17.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn17.FieldName = "UpBdRate_E";
            this.layoutViewColumn17.LayoutViewField = this.layoutViewField_layoutViewColumn17;
            this.layoutViewColumn17.Name = "layoutViewColumn17";
            this.layoutViewColumn17.OptionsColumn.AllowEdit = false;
            this.layoutViewColumn17.OptionsColumn.ReadOnly = true;
            // 
            // layoutViewField_layoutViewColumn17
            // 
            this.layoutViewField_layoutViewColumn17.EditorPreferredWidth = 254;
            this.layoutViewField_layoutViewColumn17.Location = new System.Drawing.Point(0, 151);
            this.layoutViewField_layoutViewColumn17.Name = "layoutViewField_layoutViewColumn17";
            this.layoutViewField_layoutViewColumn17.Size = new System.Drawing.Size(258, 26);
            this.layoutViewField_layoutViewColumn17.TextSize = new System.Drawing.Size(0, 0);
            this.layoutViewField_layoutViewColumn17.TextToControlDistance = 0;
            this.layoutViewField_layoutViewColumn17.TextVisible = false;
            // 
            // layoutViewColumn18
            // 
            this.layoutViewColumn18.Caption = "PPM<LSL entirety";
            this.layoutViewColumn18.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn18.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn18.FieldName = "LowBdRate_E";
            this.layoutViewColumn18.LayoutViewField = this.layoutViewField_layoutViewColumn18;
            this.layoutViewColumn18.Name = "layoutViewColumn18";
            this.layoutViewColumn18.OptionsColumn.AllowEdit = false;
            this.layoutViewColumn18.OptionsColumn.ReadOnly = true;
            // 
            // layoutViewField_layoutViewColumn18
            // 
            this.layoutViewField_layoutViewColumn18.EditorPreferredWidth = 254;
            this.layoutViewField_layoutViewColumn18.Location = new System.Drawing.Point(0, 177);
            this.layoutViewField_layoutViewColumn18.Name = "layoutViewField_layoutViewColumn18";
            this.layoutViewField_layoutViewColumn18.Size = new System.Drawing.Size(258, 26);
            this.layoutViewField_layoutViewColumn18.TextSize = new System.Drawing.Size(0, 0);
            this.layoutViewField_layoutViewColumn18.TextToControlDistance = 0;
            this.layoutViewField_layoutViewColumn18.TextVisible = false;
            // 
            // layoutViewColumn19
            // 
            this.layoutViewColumn19.Caption = "Cp entirety";
            this.layoutViewColumn19.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn19.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn19.FieldName = "CP_E";
            this.layoutViewColumn19.LayoutViewField = this.layoutViewField_layoutViewColumn19;
            this.layoutViewColumn19.Name = "layoutViewColumn19";
            this.layoutViewColumn19.OptionsColumn.AllowEdit = false;
            this.layoutViewColumn19.OptionsColumn.ReadOnly = true;
            // 
            // layoutViewField_layoutViewColumn19
            // 
            this.layoutViewField_layoutViewColumn19.EditorPreferredWidth = 254;
            this.layoutViewField_layoutViewColumn19.Location = new System.Drawing.Point(0, 47);
            this.layoutViewField_layoutViewColumn19.Name = "layoutViewField_layoutViewColumn19";
            this.layoutViewField_layoutViewColumn19.Size = new System.Drawing.Size(258, 26);
            this.layoutViewField_layoutViewColumn19.TextSize = new System.Drawing.Size(0, 0);
            this.layoutViewField_layoutViewColumn19.TextToControlDistance = 0;
            this.layoutViewField_layoutViewColumn19.TextVisible = false;
            // 
            // layoutViewColumn20
            // 
            this.layoutViewColumn20.Caption = "Cpk entirety";
            this.layoutViewColumn20.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn20.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn20.FieldName = "CPK_E";
            this.layoutViewColumn20.LayoutViewField = this.layoutViewField_layoutViewColumn20;
            this.layoutViewColumn20.Name = "layoutViewColumn20";
            this.layoutViewColumn20.OptionsColumn.AllowEdit = false;
            this.layoutViewColumn20.OptionsColumn.ReadOnly = true;
            // 
            // layoutViewField_layoutViewColumn20
            // 
            this.layoutViewField_layoutViewColumn20.EditorPreferredWidth = 254;
            this.layoutViewField_layoutViewColumn20.Location = new System.Drawing.Point(0, 73);
            this.layoutViewField_layoutViewColumn20.Name = "layoutViewField_layoutViewColumn20";
            this.layoutViewField_layoutViewColumn20.Size = new System.Drawing.Size(258, 26);
            this.layoutViewField_layoutViewColumn20.TextSize = new System.Drawing.Size(0, 0);
            this.layoutViewField_layoutViewColumn20.TextToControlDistance = 0;
            this.layoutViewField_layoutViewColumn20.TextVisible = false;
            // 
            // layoutViewColumn21
            // 
            this.layoutViewColumn21.Caption = "SelectType";
            this.layoutViewColumn21.ColumnEdit = this.repositoryItemRadioGroup1;
            this.layoutViewColumn21.FieldName = "SelectType";
            this.layoutViewColumn21.LayoutViewField = this.layoutViewField_layoutViewColumn21;
            this.layoutViewColumn21.Name = "layoutViewColumn21";
            // 
            // repositoryItemRadioGroup1
            // 
            this.repositoryItemRadioGroup1.Columns = 1;
            this.repositoryItemRadioGroup1.EnableFocusRect = true;
            this.repositoryItemRadioGroup1.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(null, "双侧公差"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(null, "上限公差"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(null, "下限公差")});
            this.repositoryItemRadioGroup1.Name = "repositoryItemRadioGroup1";
            this.repositoryItemRadioGroup1.EditValueChanged += new System.EventHandler(this.repositoryItemRadioGroup1_EditValueChanged);
            // 
            // layoutViewField_layoutViewColumn21
            // 
            this.layoutViewField_layoutViewColumn21.EditorPreferredWidth = 97;
            this.layoutViewField_layoutViewColumn21.Location = new System.Drawing.Point(119, 0);
            this.layoutViewField_layoutViewColumn21.MinSize = new System.Drawing.Size(101, 23);
            this.layoutViewField_layoutViewColumn21.Name = "layoutViewField_layoutViewColumn21";
            this.layoutViewField_layoutViewColumn21.Size = new System.Drawing.Size(101, 113);
            this.layoutViewField_layoutViewColumn21.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutViewField_layoutViewColumn21.TextSize = new System.Drawing.Size(0, 0);
            this.layoutViewField_layoutViewColumn21.TextToControlDistance = 0;
            this.layoutViewField_layoutViewColumn21.TextVisible = false;
            // 
            // layoutViewColumn22
            // 
            this.layoutViewColumn22.Caption = "+3Sigma";
            this.layoutViewColumn22.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn22.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn22.FieldName = "P3Sigma";
            this.layoutViewColumn22.LayoutViewField = this.layoutViewField_layoutViewColumn22;
            this.layoutViewColumn22.Name = "layoutViewColumn22";
            // 
            // layoutViewField_layoutViewColumn22
            // 
            this.layoutViewField_layoutViewColumn22.EditorPreferredWidth = 91;
            this.layoutViewField_layoutViewColumn22.Location = new System.Drawing.Point(0, 52);
            this.layoutViewField_layoutViewColumn22.Name = "layoutViewField_layoutViewColumn22";
            this.layoutViewField_layoutViewColumn22.Size = new System.Drawing.Size(170, 26);
            this.layoutViewField_layoutViewColumn22.TextSize = new System.Drawing.Size(75, 16);
            this.layoutViewField_layoutViewColumn22.TextToControlDistance = 0;
            // 
            // layoutViewColumn23
            // 
            this.layoutViewColumn23.Caption = "-3Sigma";
            this.layoutViewColumn23.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn23.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn23.FieldName = "N3Sigma";
            this.layoutViewColumn23.LayoutViewField = this.layoutViewField_layoutViewColumn23;
            this.layoutViewColumn23.Name = "layoutViewColumn23";
            // 
            // layoutViewField_layoutViewColumn23
            // 
            this.layoutViewField_layoutViewColumn23.EditorPreferredWidth = 80;
            this.layoutViewField_layoutViewColumn23.Location = new System.Drawing.Point(0, 52);
            this.layoutViewField_layoutViewColumn23.Name = "layoutViewField_layoutViewColumn23";
            this.layoutViewField_layoutViewColumn23.Size = new System.Drawing.Size(159, 26);
            this.layoutViewField_layoutViewColumn23.TextSize = new System.Drawing.Size(75, 16);
            this.layoutViewField_layoutViewColumn23.TextToControlDistance = 0;
            // 
            // layoutViewColumn24
            // 
            this.layoutViewColumn24.Caption = "CPL entirety";
            this.layoutViewColumn24.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn24.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn24.FieldName = "CPL_E";
            this.layoutViewColumn24.LayoutViewField = this.layoutViewField_layoutViewColumn24;
            this.layoutViewColumn24.Name = "layoutViewColumn24";
            // 
            // layoutViewField_layoutViewColumn24
            // 
            this.layoutViewField_layoutViewColumn24.EditorPreferredWidth = 254;
            this.layoutViewField_layoutViewColumn24.Location = new System.Drawing.Point(0, 125);
            this.layoutViewField_layoutViewColumn24.Name = "layoutViewField_layoutViewColumn24";
            this.layoutViewField_layoutViewColumn24.Size = new System.Drawing.Size(258, 26);
            this.layoutViewField_layoutViewColumn24.TextSize = new System.Drawing.Size(0, 0);
            this.layoutViewField_layoutViewColumn24.TextToControlDistance = 0;
            this.layoutViewField_layoutViewColumn24.TextVisible = false;
            // 
            // layoutViewColumn25
            // 
            this.layoutViewColumn25.Caption = "CPU entirety";
            this.layoutViewColumn25.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn25.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn25.FieldName = "CPU_E";
            this.layoutViewColumn25.LayoutViewField = this.layoutViewField_layoutViewColumn25;
            this.layoutViewColumn25.Name = "layoutViewColumn25";
            // 
            // layoutViewField_layoutViewColumn25
            // 
            this.layoutViewField_layoutViewColumn25.EditorPreferredWidth = 254;
            this.layoutViewField_layoutViewColumn25.Location = new System.Drawing.Point(0, 99);
            this.layoutViewField_layoutViewColumn25.Name = "layoutViewField_layoutViewColumn25";
            this.layoutViewField_layoutViewColumn25.Size = new System.Drawing.Size(258, 26);
            this.layoutViewField_layoutViewColumn25.TextSize = new System.Drawing.Size(0, 0);
            this.layoutViewField_layoutViewColumn25.TextToControlDistance = 0;
            this.layoutViewField_layoutViewColumn25.TextVisible = false;
            // 
            // layoutViewColumn26
            // 
            this.layoutViewColumn26.Caption = "PPM>USL";
            this.layoutViewColumn26.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn26.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn26.FieldName = "UpBdRate_G";
            this.layoutViewColumn26.LayoutViewField = this.layoutViewField_layoutViewColumn26;
            this.layoutViewColumn26.Name = "layoutViewColumn26";
            // 
            // layoutViewField_layoutViewColumn26
            // 
            this.layoutViewField_layoutViewColumn26.EditorPreferredWidth = 255;
            this.layoutViewField_layoutViewColumn26.Location = new System.Drawing.Point(0, 151);
            this.layoutViewField_layoutViewColumn26.Name = "layoutViewField_layoutViewColumn26";
            this.layoutViewField_layoutViewColumn26.Size = new System.Drawing.Size(321, 26);
            this.layoutViewField_layoutViewColumn26.TextSize = new System.Drawing.Size(62, 16);
            this.layoutViewField_layoutViewColumn26.TextToControlDistance = 0;
            // 
            // layoutViewColumn27
            // 
            this.layoutViewColumn27.Caption = "PPM<LSL";
            this.layoutViewColumn27.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn27.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn27.FieldName = "LowBdRate_G";
            this.layoutViewColumn27.LayoutViewField = this.layoutViewField_layoutViewColumn27;
            this.layoutViewColumn27.Name = "layoutViewColumn27";
            // 
            // layoutViewField_layoutViewColumn27
            // 
            this.layoutViewField_layoutViewColumn27.EditorPreferredWidth = 255;
            this.layoutViewField_layoutViewColumn27.Location = new System.Drawing.Point(0, 177);
            this.layoutViewField_layoutViewColumn27.Name = "layoutViewField_layoutViewColumn27";
            this.layoutViewField_layoutViewColumn27.Size = new System.Drawing.Size(321, 26);
            this.layoutViewField_layoutViewColumn27.TextSize = new System.Drawing.Size(62, 16);
            this.layoutViewField_layoutViewColumn27.TextToControlDistance = 0;
            // 
            // layoutViewColumn28
            // 
            this.layoutViewColumn28.Caption = "PPM Total";
            this.layoutViewColumn28.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn28.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn28.FieldName = "SumBdRate_G";
            this.layoutViewColumn28.LayoutViewField = this.layoutViewField_layoutViewColumn28;
            this.layoutViewColumn28.Name = "layoutViewColumn28";
            // 
            // layoutViewField_layoutViewColumn28
            // 
            this.layoutViewField_layoutViewColumn28.EditorPreferredWidth = 255;
            this.layoutViewField_layoutViewColumn28.Location = new System.Drawing.Point(0, 203);
            this.layoutViewField_layoutViewColumn28.Name = "layoutViewField_layoutViewColumn28";
            this.layoutViewField_layoutViewColumn28.Size = new System.Drawing.Size(321, 26);
            this.layoutViewField_layoutViewColumn28.TextSize = new System.Drawing.Size(62, 16);
            this.layoutViewField_layoutViewColumn28.TextToControlDistance = 0;
            // 
            // layoutViewColumn29
            // 
            this.layoutViewColumn29.Caption = "Cp";
            this.layoutViewColumn29.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn29.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn29.FieldName = "CP_G";
            this.layoutViewColumn29.LayoutViewField = this.layoutViewField_layoutViewColumn29;
            this.layoutViewColumn29.Name = "layoutViewColumn29";
            // 
            // layoutViewField_layoutViewColumn29
            // 
            this.layoutViewField_layoutViewColumn29.EditorPreferredWidth = 255;
            this.layoutViewField_layoutViewColumn29.Location = new System.Drawing.Point(0, 47);
            this.layoutViewField_layoutViewColumn29.Name = "layoutViewField_layoutViewColumn29";
            this.layoutViewField_layoutViewColumn29.Size = new System.Drawing.Size(321, 26);
            this.layoutViewField_layoutViewColumn29.TextSize = new System.Drawing.Size(62, 16);
            this.layoutViewField_layoutViewColumn29.TextToControlDistance = 0;
            // 
            // layoutViewColumn30
            // 
            this.layoutViewColumn30.Caption = "Cpk";
            this.layoutViewColumn30.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn30.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn30.FieldName = "CPK_G";
            this.layoutViewColumn30.LayoutViewField = this.layoutViewField_layoutViewColumn30;
            this.layoutViewColumn30.Name = "layoutViewColumn30";
            // 
            // layoutViewField_layoutViewColumn30
            // 
            this.layoutViewField_layoutViewColumn30.EditorPreferredWidth = 255;
            this.layoutViewField_layoutViewColumn30.Location = new System.Drawing.Point(0, 73);
            this.layoutViewField_layoutViewColumn30.Name = "layoutViewField_layoutViewColumn30";
            this.layoutViewField_layoutViewColumn30.Size = new System.Drawing.Size(321, 26);
            this.layoutViewField_layoutViewColumn30.TextSize = new System.Drawing.Size(62, 16);
            this.layoutViewField_layoutViewColumn30.TextToControlDistance = 0;
            // 
            // layoutViewColumn31
            // 
            this.layoutViewColumn31.Caption = "CPL";
            this.layoutViewColumn31.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn31.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn31.FieldName = "CPL_G";
            this.layoutViewColumn31.LayoutViewField = this.layoutViewField_layoutViewColumn31;
            this.layoutViewColumn31.Name = "layoutViewColumn31";
            // 
            // layoutViewField_layoutViewColumn31
            // 
            this.layoutViewField_layoutViewColumn31.EditorPreferredWidth = 255;
            this.layoutViewField_layoutViewColumn31.Location = new System.Drawing.Point(0, 125);
            this.layoutViewField_layoutViewColumn31.Name = "layoutViewField_layoutViewColumn31";
            this.layoutViewField_layoutViewColumn31.Size = new System.Drawing.Size(321, 26);
            this.layoutViewField_layoutViewColumn31.TextSize = new System.Drawing.Size(62, 16);
            this.layoutViewField_layoutViewColumn31.TextToControlDistance = 0;
            // 
            // layoutViewColumn32
            // 
            this.layoutViewColumn32.Caption = "CPU";
            this.layoutViewColumn32.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn32.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn32.FieldName = "CPU_G";
            this.layoutViewColumn32.LayoutViewField = this.layoutViewField_layoutViewColumn32;
            this.layoutViewColumn32.Name = "layoutViewColumn32";
            // 
            // layoutViewField_layoutViewColumn32
            // 
            this.layoutViewField_layoutViewColumn32.EditorPreferredWidth = 255;
            this.layoutViewField_layoutViewColumn32.Location = new System.Drawing.Point(0, 99);
            this.layoutViewField_layoutViewColumn32.Name = "layoutViewField_layoutViewColumn32";
            this.layoutViewField_layoutViewColumn32.Size = new System.Drawing.Size(321, 26);
            this.layoutViewField_layoutViewColumn32.TextSize = new System.Drawing.Size(62, 16);
            this.layoutViewField_layoutViewColumn32.TextToControlDistance = 0;
            // 
            // layoutViewColumn2
            // 
            this.layoutViewColumn2.Caption = "STDEV";
            this.layoutViewColumn2.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn2.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn2.FieldName = "STDev_G";
            this.layoutViewColumn2.LayoutViewField = this.layoutViewField_layoutViewColumn2;
            this.layoutViewColumn2.Name = "layoutViewColumn2";
            // 
            // layoutViewField_layoutViewColumn2
            // 
            this.layoutViewField_layoutViewColumn2.EditorPreferredWidth = 255;
            this.layoutViewField_layoutViewColumn2.Location = new System.Drawing.Point(0, 21);
            this.layoutViewField_layoutViewColumn2.Name = "layoutViewField_layoutViewColumn2";
            this.layoutViewField_layoutViewColumn2.Size = new System.Drawing.Size(321, 26);
            this.layoutViewField_layoutViewColumn2.TextSize = new System.Drawing.Size(62, 16);
            this.layoutViewField_layoutViewColumn2.TextToControlDistance = 0;
            // 
            // layoutViewColumn10
            // 
            this.layoutViewColumn10.Caption = "STDEV entirety";
            this.layoutViewColumn10.DisplayFormat.FormatString = "0.####";
            this.layoutViewColumn10.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.layoutViewColumn10.FieldName = "STDev_E";
            this.layoutViewColumn10.LayoutViewField = this.layoutViewField_layoutViewColumn10;
            this.layoutViewColumn10.Name = "layoutViewColumn10";
            // 
            // layoutViewField_layoutViewColumn10
            // 
            this.layoutViewField_layoutViewColumn10.EditorPreferredWidth = 254;
            this.layoutViewField_layoutViewColumn10.Location = new System.Drawing.Point(0, 21);
            this.layoutViewField_layoutViewColumn10.Name = "layoutViewField_layoutViewColumn10";
            this.layoutViewField_layoutViewColumn10.Size = new System.Drawing.Size(258, 26);
            this.layoutViewField_layoutViewColumn10.TextSize = new System.Drawing.Size(0, 0);
            this.layoutViewField_layoutViewColumn10.TextToControlDistance = 0;
            this.layoutViewField_layoutViewColumn10.TextVisible = false;
            // 
            // layoutViewColumn33
            // 
            this.layoutViewColumn33.Caption = "子组大小";
            this.layoutViewColumn33.ColumnEdit = this.repositoryItemTextEdit4;
            this.layoutViewColumn33.FieldName = "GroupLength";
            this.layoutViewColumn33.LayoutViewField = this.layoutViewField_layoutViewColumn33;
            this.layoutViewColumn33.Name = "layoutViewColumn33";
            // 
            // repositoryItemTextEdit4
            // 
            this.repositoryItemTextEdit4.AutoHeight = false;
            this.repositoryItemTextEdit4.Mask.EditMask = "[1-9]\\d*";
            this.repositoryItemTextEdit4.Mask.IgnoreMaskBlank = false;
            this.repositoryItemTextEdit4.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx;
            this.repositoryItemTextEdit4.Mask.ShowPlaceHolders = false;
            this.repositoryItemTextEdit4.Name = "repositoryItemTextEdit4";
            // 
            // layoutViewField_layoutViewColumn33
            // 
            this.layoutViewField_layoutViewColumn33.EditorPreferredWidth = 54;
            this.layoutViewField_layoutViewColumn33.Location = new System.Drawing.Point(0, 78);
            this.layoutViewField_layoutViewColumn33.Name = "layoutViewField_layoutViewColumn33";
            this.layoutViewField_layoutViewColumn33.Size = new System.Drawing.Size(119, 35);
            this.layoutViewField_layoutViewColumn33.TextSize = new System.Drawing.Size(61, 17);
            this.layoutViewField_layoutViewColumn33.TextToControlDistance = 0;
            // 
            // layoutViewCard1
            // 
            this.layoutViewCard1.AllowDrawBackground = false;
            this.layoutViewCard1.CustomizationFormText = "TemplateCard";
            this.layoutViewCard1.ExpandButtonLocation = DevExpress.Utils.GroupElementLocation.AfterText;
            this.layoutViewCard1.GroupBordersVisible = false;
            this.layoutViewCard1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.Group1,
            this.Group2,
            this.Group5,
            this.Group7});
            this.layoutViewCard1.Name = "layoutViewTemplateCard";
            this.layoutViewCard1.OptionsItemText.TextToControlDistance = 0;
            this.layoutViewCard1.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.layoutViewCard1.Text = "TemplateCard";
            this.layoutViewCard1.TextLocation = DevExpress.Utils.Locations.Bottom;
            // 
            // Group1
            // 
            this.Group1.CustomizationFormText = "Group1";
            this.Group1.GroupBordersVisible = false;
            this.Group1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.Group3,
            this.Group4});
            this.Group1.Location = new System.Drawing.Point(0, 86);
            this.Group1.Name = "Group1";
            this.Group1.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.Group1.Size = new System.Drawing.Size(337, 86);
            this.Group1.Text = "Group1";
            // 
            // Group3
            // 
            this.Group3.CustomizationFormText = "Group3";
            this.Group3.GroupBordersVisible = false;
            this.Group3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutViewField_layoutViewColumn6,
            this.layoutViewField_layoutViewColumn8,
            this.layoutViewField_layoutViewColumn9});
            this.Group3.Location = new System.Drawing.Point(0, 0);
            this.Group3.Name = "Group3";
            this.Group3.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.Group3.Size = new System.Drawing.Size(170, 78);
            this.Group3.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.Group3.Text = "Group3";
            // 
            // Group4
            // 
            this.Group4.CustomizationFormText = "Group4";
            this.Group4.GroupBordersVisible = false;
            this.Group4.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutViewField_layoutViewColumn7,
            this.layoutViewField_layoutViewColumn11,
            this.layoutViewField_layoutViewColumn12});
            this.Group4.Location = new System.Drawing.Point(170, 0);
            this.Group4.Name = "Group4";
            this.Group4.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.Group4.Size = new System.Drawing.Size(159, 78);
            this.Group4.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.Group4.Text = "Group4";
            // 
            // Group2
            // 
            this.Group2.CustomizationFormText = "Group2";
            this.Group2.GroupBordersVisible = false;
            this.Group2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.Group8,
            this.Group9});
            this.Group2.Location = new System.Drawing.Point(0, 0);
            this.Group2.Name = "Group2";
            this.Group2.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.Group2.Size = new System.Drawing.Size(337, 86);
            this.Group2.Text = "Group2";
            // 
            // Group8
            // 
            this.Group8.CustomizationFormText = "Group8";
            this.Group8.GroupBordersVisible = false;
            this.Group8.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutViewField_layoutViewColumn1,
            this.layoutViewField_layoutViewColumn14,
            this.layoutViewField_layoutViewColumn22});
            this.Group8.Location = new System.Drawing.Point(0, 0);
            this.Group8.Name = "Group8";
            this.Group8.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.Group8.Size = new System.Drawing.Size(170, 78);
            this.Group8.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.Group8.Text = "Group8";
            // 
            // Group9
            // 
            this.Group9.CustomizationFormText = "Group9";
            this.Group9.GroupBordersVisible = false;
            this.Group9.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutViewField_layoutViewColumn15,
            this.layoutViewField_layoutViewColumn3,
            this.layoutViewField_layoutViewColumn23});
            this.Group9.Location = new System.Drawing.Point(170, 0);
            this.Group9.Name = "Group9";
            this.Group9.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.Group9.Size = new System.Drawing.Size(159, 78);
            this.Group9.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.Group9.Text = "Group9";
            // 
            // Group5
            // 
            this.Group5.CustomizationFormText = "Group5";
            this.Group5.GroupBordersVisible = false;
            this.Group5.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.Group6,
            this.Group10});
            this.Group5.Location = new System.Drawing.Point(0, 172);
            this.Group5.Name = "Group5";
            this.Group5.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.Group5.Size = new System.Drawing.Size(587, 237);
            this.Group5.Text = "Group5";
            // 
            // Group6
            // 
            this.Group6.CustomizationFormText = "Group6";
            this.Group6.GroupBordersVisible = false;
            this.Group6.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.item2,
            this.layoutViewField_layoutViewColumn16,
            this.layoutViewField_layoutViewColumn18,
            this.layoutViewField_layoutViewColumn17,
            this.layoutViewField_layoutViewColumn24,
            this.layoutViewField_layoutViewColumn25,
            this.layoutViewField_layoutViewColumn20,
            this.layoutViewField_layoutViewColumn19,
            this.layoutViewField_layoutViewColumn10});
            this.Group6.Location = new System.Drawing.Point(321, 0);
            this.Group6.Name = "Group6";
            this.Group6.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.Group6.Size = new System.Drawing.Size(258, 229);
            this.Group6.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.Group6.Text = "Group6";
            // 
            // item2
            // 
            this.item2.AllowHotTrack = false;
            this.item2.AppearanceItemCaption.Options.UseTextOptions = true;
            this.item2.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.item2.CustomizationFormText = "整体";
            this.item2.Location = new System.Drawing.Point(0, 0);
            this.item2.Name = "item2";
            this.item2.Size = new System.Drawing.Size(258, 21);
            this.item2.Text = "整体";
            this.item2.TextSize = new System.Drawing.Size(28, 17);
            // 
            // Group10
            // 
            this.Group10.CustomizationFormText = "Group10";
            this.Group10.GroupBordersVisible = false;
            this.Group10.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.item1,
            this.item3,
            this.layoutViewField_layoutViewColumn29,
            this.layoutViewField_layoutViewColumn30,
            this.layoutViewField_layoutViewColumn32,
            this.layoutViewField_layoutViewColumn31,
            this.layoutViewField_layoutViewColumn26,
            this.layoutViewField_layoutViewColumn27,
            this.layoutViewField_layoutViewColumn28,
            this.layoutViewField_layoutViewColumn2});
            this.Group10.Location = new System.Drawing.Point(0, 0);
            this.Group10.Name = "Group10";
            this.Group10.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.Group10.Size = new System.Drawing.Size(321, 229);
            this.Group10.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.Group10.Text = "Group10";
            // 
            // item1
            // 
            this.item1.AllowHotTrack = false;
            this.item1.AppearanceItemCaption.Options.UseTextOptions = true;
            this.item1.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.item1.CustomizationFormText = "组内";
            this.item1.Location = new System.Drawing.Point(63, 0);
            this.item1.Name = "item1";
            this.item1.Size = new System.Drawing.Size(258, 21);
            this.item1.Text = "组内";
            this.item1.TextSize = new System.Drawing.Size(62, 17);
            // 
            // item3
            // 
            this.item3.AllowHotTrack = false;
            this.item3.CustomizationFormText = "item3";
            this.item3.Location = new System.Drawing.Point(0, 0);
            this.item3.Name = "item3";
            this.item3.Size = new System.Drawing.Size(63, 21);
            this.item3.Text = "item3";
            this.item3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // Group7
            // 
            this.Group7.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 12.83019F);
            this.Group7.AppearanceGroup.Options.UseFont = true;
            this.Group7.AppearanceGroup.Options.UseTextOptions = true;
            this.Group7.AppearanceGroup.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.Group7.CustomizationFormText = "设定";
            this.Group7.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutViewField_layoutViewColumn4,
            this.layoutViewField_layoutViewColumn13,
            this.layoutViewField_layoutViewColumn5,
            this.layoutViewField_layoutViewColumn33,
            this.layoutViewField_layoutViewColumn21});
            this.Group7.Location = new System.Drawing.Point(337, 0);
            this.Group7.Name = "Group7";
            this.Group7.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.Group7.Size = new System.Drawing.Size(250, 172);
            this.Group7.Spacing = new DevExpress.XtraLayout.Utils.Padding(12, 12, 12, 12);
            this.Group7.Text = "设定";
            // 
            // panelControl2
            // 
            this.panelControl2.Controls.Add(this.DataChart);
            this.panelControl2.Controls.Add(this.splitter2);
            this.panelControl2.Controls.Add(this.panelControl3);
            this.panelControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl2.Location = new System.Drawing.Point(624, 0);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(738, 586);
            this.panelControl2.TabIndex = 10;
            // 
            // DataChart
            // 
            this.DataChart.AllowDrop = true;
            this.DataChart.BorderOptions.Visible = false;
            constantLine1.AxisValueSerializable = "B";
            constantLine1.Name = "X";
            constantLine1.Title.Text = "X";
            constantLine1.Visible = false;
            constantLine2.AxisValueSerializable = "B";
            constantLine2.Name = "X";
            constantLine2.Title.Text = "X";
            constantLine2.Visible = false;
            swiftPlotDiagram1.AxisX.ConstantLines.AddRange(new DevExpress.XtraCharts.ConstantLine[] {
            constantLine1,
            constantLine2});
            swiftPlotDiagram1.AxisX.MinorCount = 1;
            strip1.MaxLimit.AxisValueSerializable = "B";
            strip1.MinLimit.AxisValueSerializable = "A";
            strip1.Name = "XStrip";
            strip1.Visible = false;
            swiftPlotDiagram1.AxisX.Strips.AddRange(new DevExpress.XtraCharts.Strip[] {
            strip1});
            swiftPlotDiagram1.AxisX.VisibleInPanesSerializable = "-1";
            swiftPlotDiagram1.AxisX.WholeRange.AutoSideMargins = false;
            swiftPlotDiagram1.AxisX.WholeRange.SideMarginsValue = 0D;
            constantLine3.AxisValueSerializable = "0";
            constantLine3.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            constantLine3.LineStyle.DashStyle = DevExpress.XtraCharts.DashStyle.Solid;
            constantLine3.Name = "up";
            constantLine3.ShowInLegend = false;
            constantLine3.Title.Visible = false;
            constantLine3.Visible = false;
            constantLine4.AxisValueSerializable = "0";
            constantLine4.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            constantLine4.LineStyle.DashStyle = DevExpress.XtraCharts.DashStyle.Dash;
            constantLine4.Name = "std";
            constantLine4.ShowInLegend = false;
            constantLine4.Title.Visible = false;
            constantLine4.Visible = false;
            constantLine5.AxisValueSerializable = "0";
            constantLine5.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            constantLine5.LineStyle.DashStyle = DevExpress.XtraCharts.DashStyle.Solid;
            constantLine5.Name = "low";
            constantLine5.ShowInLegend = false;
            constantLine5.Title.Visible = false;
            constantLine5.Visible = false;
            constantLine6.AxisValueSerializable = "1";
            constantLine6.Name = "Y";
            constantLine6.Title.Text = "Y";
            constantLine6.Visible = false;
            constantLine7.AxisValueSerializable = "1";
            constantLine7.Name = "Y";
            constantLine7.Title.Text = "Y";
            constantLine7.Visible = false;
            swiftPlotDiagram1.AxisY.ConstantLines.AddRange(new DevExpress.XtraCharts.ConstantLine[] {
            constantLine3,
            constantLine4,
            constantLine5,
            constantLine6,
            constantLine7});
            strip2.MaxLimit.AxisValueSerializable = "1";
            strip2.MinLimit.AxisValueSerializable = "0";
            strip2.Name = "YStrip";
            strip2.Visible = false;
            swiftPlotDiagram1.AxisY.Strips.AddRange(new DevExpress.XtraCharts.Strip[] {
            strip2});
            swiftPlotDiagram1.AxisY.VisibleInPanesSerializable = "-1";
            swiftPlotDiagram1.AxisY.WholeRange.AlwaysShowZeroLevel = false;
            swiftPlotDiagram1.EnableAxisXScrolling = true;
            swiftPlotDiagram1.EnableAxisXZooming = true;
            swiftPlotDiagram1.Margins.Bottom = 0;
            swiftPlotDiagram1.Margins.Left = 0;
            swiftPlotDiagram1.Margins.Right = 0;
            swiftPlotDiagram1.Margins.Top = 0;
            swiftPlotDiagram1.ScrollingOptions.UseMouse = false;
            this.DataChart.Diagram = swiftPlotDiagram1;
            this.DataChart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DataChart.Legend.Visible = false;
            this.DataChart.Location = new System.Drawing.Point(2, 2);
            this.DataChart.Name = "DataChart";
            this.DataChart.Padding.Bottom = 0;
            this.DataChart.Padding.Left = 0;
            this.DataChart.Padding.Right = 0;
            this.DataChart.Padding.Top = 0;
            this.DataChart.RuntimeHitTesting = true;
            series1.ArgumentScaleType = DevExpress.XtraCharts.ScaleType.Qualitative;
            series1.Name = "Series 1";
            series1.View = swiftPlotSeriesView1;
            this.DataChart.SeriesSerializable = new DevExpress.XtraCharts.Series[] {
        series1};
            swiftPlotSeriesView2.LineStyle.Thickness = 2;
            this.DataChart.SeriesTemplate.View = swiftPlotSeriesView2;
            this.DataChart.Size = new System.Drawing.Size(734, 102);
            this.DataChart.TabIndex = 16;
            this.DataChart.CustomDrawCrosshair += new DevExpress.XtraCharts.CustomDrawCrosshairEventHandler(this.chartControl1_CustomDrawCrosshair);
            this.DataChart.MouseDown += new System.Windows.Forms.MouseEventHandler(this.chartControl1_MouseDown);
            this.DataChart.MouseMove += new System.Windows.Forms.MouseEventHandler(this.chartControl1_MouseMove);
            this.DataChart.MouseUp += new System.Windows.Forms.MouseEventHandler(this.chartControl1_MouseUp);
            // 
            // splitter2
            // 
            this.splitter2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter2.Location = new System.Drawing.Point(2, 104);
            this.splitter2.Name = "splitter2";
            this.splitter2.Size = new System.Drawing.Size(734, 3);
            this.splitter2.TabIndex = 17;
            this.splitter2.TabStop = false;
            // 
            // panelControl3
            // 
            this.panelControl3.Controls.Add(this.gridControl2);
            this.panelControl3.Controls.Add(this.standaloneBarDockControl1);
            this.panelControl3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelControl3.Location = new System.Drawing.Point(2, 107);
            this.panelControl3.Name = "panelControl3";
            this.panelControl3.Size = new System.Drawing.Size(734, 477);
            this.panelControl3.TabIndex = 19;
            // 
            // gridControl2
            // 
            this.gridControl2.AllowDrop = true;
            this.gridControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControl2.Location = new System.Drawing.Point(2, 29);
            this.gridControl2.MainView = this.gridView1;
            this.gridControl2.MenuManager = this.barManager1;
            this.gridControl2.Name = "gridControl2";
            this.gridControl2.Size = new System.Drawing.Size(730, 446);
            this.gridControl2.TabIndex = 14;
            this.gridControl2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.ChooseColumnName = "choose";
            this.gridView1.GridControl = this.gridControl2;
            this.gridView1.Name = "gridView1";
            this.gridView1.NumberDisplayFormat = "";
            this.gridView1.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.False;
            this.gridView1.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.False;
            this.gridView1.OptionsBehavior.Editable = false;
            this.gridView1.OptionsBehavior.ReadOnly = true;
            this.gridView1.OptionsCustomization.AllowQuickHideColumns = false;
            this.gridView1.OptionsSelection.MultiSelect = true;
            this.gridView1.OptionsView.ColumnAutoWidth = false;
            this.gridView1.OptionsView.ShowFooter = true;
            this.gridView1.DragObjectDrop += new DevExpress.XtraGrid.Views.Base.DragObjectDropEventHandler(this.gridView1_DragObjectDrop);
            // 
            // chartPointRightClickPopupMenu
            // 
            this.chartPointRightClickPopupMenu.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barStaticItem1),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barButtonItem2, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph)});
            this.chartPointRightClickPopupMenu.Manager = this.barManager1;
            this.chartPointRightClickPopupMenu.Name = "chartPointRightClickPopupMenu";
            // 
            // ChartBoundRightClickPopupMenu
            // 
            this.ChartBoundRightClickPopupMenu.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barStaticItem2),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barButtonItem5, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(this.barEditItem3),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem6)});
            this.ChartBoundRightClickPopupMenu.Manager = this.barManager1;
            this.ChartBoundRightClickPopupMenu.Name = "ChartBoundRightClickPopupMenu";
            // 
            // gridViewRightClickPopupMenu
            // 
            this.gridViewRightClickPopupMenu.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem4),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem11)});
            this.gridViewRightClickPopupMenu.Manager = this.barManager1;
            this.gridViewRightClickPopupMenu.Name = "gridViewRightClickPopupMenu";
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(621, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 586);
            this.splitter1.TabIndex = 17;
            this.splitter1.TabStop = false;
            // 
            // CPKtoolControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelControl2);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "CPKtoolControl";
            this.Size = new System.Drawing.Size(1362, 586);
            this.Load += new System.EventHandler(this.CPKtoolControl_Load);
            this.SizeChanged += new System.EventHandler(this.CPKtoolControl_SizeChanged);
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(secondaryAxisY1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(xyDiagram1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(splineSeriesView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(splineSeriesView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartControl2)).EndInit();
            this.xtraScrollableControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRadioGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumn33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewCard1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.item2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.item1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.item3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Group7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(strip1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(strip2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(swiftPlotDiagram1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(swiftPlotSeriesView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(swiftPlotSeriesView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataChart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).EndInit();
            this.panelControl3.ResumeLayout(false);
            this.panelControl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartPointRightClickPopupMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ChartBoundRightClickPopupMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewRightClickPopupMenu)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.Bar bar2;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraEditors.PanelControl panelControl2;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem3;
        private DevExpress.XtraGrid.GridControl gridControl2;
        private SPC.Base.Control.CanChooseDataGridView gridView1;
        private DevExpress.XtraBars.BarEditItem barEditItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox2;
        private DevExpress.XtraCharts.ChartControl DataChart;
        private DevExpress.XtraCharts.ChartControl chartControl2;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Layout.LayoutView layoutView1;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn1;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn3;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn13;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn4;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn15;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn14;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn6;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn7;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn8;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn9;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn11;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn12;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn16;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn17;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn18;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn19;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn20;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn21;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn22;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn23;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn24;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn25;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn26;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn27;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn28;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn29;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn30;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn31;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn32;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn2;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn10;
        private DevExpress.XtraBars.BarEditItem barEditItem2;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit2;
        private DevExpress.XtraBars.BarEditItem barEditItem4;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox3;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn5;
        private DevExpress.XtraEditors.Repository.RepositoryItemRadioGroup repositoryItemRadioGroup1;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumn33;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn1;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn3;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn13;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn4;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn5;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn15;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn14;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn6;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn7;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn8;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn9;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn11;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn12;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn16;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn17;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn18;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn19;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn20;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn21;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn22;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn23;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn24;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn25;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn26;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn27;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn28;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn29;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn30;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn31;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn32;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn2;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn10;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumn33;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewCard layoutViewCard1;
        private DevExpress.XtraLayout.LayoutControlGroup Group1;
        private DevExpress.XtraLayout.LayoutControlGroup Group3;
        private DevExpress.XtraLayout.LayoutControlGroup Group4;
        private DevExpress.XtraLayout.LayoutControlGroup Group2;
        private DevExpress.XtraLayout.LayoutControlGroup Group8;
        private DevExpress.XtraLayout.LayoutControlGroup Group9;
        private DevExpress.XtraLayout.LayoutControlGroup Group5;
        private DevExpress.XtraLayout.LayoutControlGroup Group6;
        private DevExpress.XtraLayout.SimpleLabelItem item2;
        private DevExpress.XtraLayout.LayoutControlGroup Group10;
        private DevExpress.XtraLayout.SimpleLabelItem item1;
        private DevExpress.XtraLayout.EmptySpaceItem item3;
        private DevExpress.XtraLayout.LayoutControlGroup Group7;
        private DevExpress.XtraBars.BarStaticItem barStaticItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraBars.PopupMenu chartPointRightClickPopupMenu;
        private DevExpress.XtraBars.BarStaticItem barStaticItem2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem5;
        private DevExpress.XtraBars.BarEditItem barEditItem3;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit3;
        private DevExpress.XtraBars.BarButtonItem barButtonItem6;
        private DevExpress.XtraBars.PopupMenu ChartBoundRightClickPopupMenu;
        private DevExpress.XtraBars.BarButtonItem barButtonItem8;
        private DevExpress.XtraBars.BarButtonItem barButtonItem9;
        private DevExpress.XtraBars.BarButtonItem barButtonItem10;
        private DevExpress.XtraBars.PopupMenu gridViewRightClickPopupMenu;
        private DevExpress.XtraBars.BarButtonItem barButtonItem4;
        private DevExpress.XtraBars.BarButtonItem barButtonItem11;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Splitter splitter2;
        private System.Windows.Forms.Splitter splitter3;
        private DevExpress.XtraBars.StandaloneBarDockControl standaloneBarDockControl1;
        private DevExpress.XtraEditors.PanelControl panelControl3;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit5;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit6;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit7;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit4;
        private DevExpress.XtraEditors.XtraScrollableControl xtraScrollableControl1;

    }
}
